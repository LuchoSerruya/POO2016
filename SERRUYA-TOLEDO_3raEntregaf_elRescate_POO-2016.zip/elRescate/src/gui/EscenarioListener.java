package gui;

import java.util.ArrayList;
import elRescate.Elemento;

public interface EscenarioListener {
	
	public void actualizar(ArrayList<Elemento> elementos);

}
