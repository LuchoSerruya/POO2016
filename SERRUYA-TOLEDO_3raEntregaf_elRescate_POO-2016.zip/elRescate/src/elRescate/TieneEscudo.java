package elRescate;
/**
 * Interfaz a implementar por todos los elementos que tengan escudo
 * Robot/Satelite
 */
public interface TieneEscudo {
	

	public void setNivelEscudo(int nivelEscudo);
	public int getNivelEscudo();

}
